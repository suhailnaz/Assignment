    </div> <!-- End of container -->
    <footer class="footer mt-auto py-3 bg-light">
        <div class="container text-center">
            <span class="text-muted">&copy; <?php echo date("Y"); ?> Car Management System. All rights reserved.</span>
        </div>
    </footer>
    <script src="/js/bootstrap.min.js"></script>
</body>
</html>
